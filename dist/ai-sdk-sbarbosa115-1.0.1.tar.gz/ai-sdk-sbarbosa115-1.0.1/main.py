from src.entity.user import User

user = User()

setattr(user, 'username', 'leomessi')

print(user.username)
