class User:

    def __init__(self):
        self.username = None

    pass 
